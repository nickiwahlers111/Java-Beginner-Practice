package com.company;

public class Array_list extends Generic_List {

    @Override
    void Build_List() {

    }
}
