package com.company;


//create a utility class that handles IO as base and derive everything
public class Demo1 {


}
