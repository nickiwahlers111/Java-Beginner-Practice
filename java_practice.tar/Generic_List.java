package com.company;

abstract class Generic_List extends Utility{

    abstract void Build_List();
}
