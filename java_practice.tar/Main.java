package com.company;

import java.io.*;
import java.util.Scanner;

public class Main extends Utility {


    public static void main(String[] args) {
	// write your code here
       Utility obj = new Utility();

       Linked_List list1 = new Linked_List();

       list1.Build_List();




       /*
       System.out.println("HOW MANY PEOPLE MAX: ");
        int num = obj.input.nextInt();
       Person [] people_array  = new Person[num];
       boolean quit = false;
       int i = 0;

       do{
            people_array[i] = new Person();
           people_array[i].set_person();
           ++i;
           System.out.println("QUIT? (true or false) : ");
           quit = obj.input.nextBoolean();

       }while(i < num && !quit);*/





        //System.out.println("Please enter a num: ");
     // int num = obj.input.nextInt();
      //System.out.println(num);


      //start calling person functions
      //  Person my_person = new Person();

//        my_person.set_person();
 //    my_person.display();

      /*  String compare = new String();
        System.out.println("ENTER A NAME TO COMPARE: ");
        compare = obj.input.next();

        if(my_person.compare_person(compare)){
            System.out.println("compare worked");
        }*/


    }

}
